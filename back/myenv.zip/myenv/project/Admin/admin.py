from django.contrib import admin
from .models import *
admin.site.register(Enseignant)
admin.site.register(Module)
admin.site.register(Enseigne)
admin.site.register(Salle)
admin.site.register(Specialite)
admin.site.register(Seance)
admin.site.register(Promotion)
admin.site.register(Groupe)
admin.site.register(heure)
admin.site.register(SpecPromo)
admin.site.register(section)
admin.site.register(Abcence)

# Register your models here.
